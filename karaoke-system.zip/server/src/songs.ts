import { Router } from 'express';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { db } from './db.js';
import type { Song } from './types.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const uploadsDir = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${crypto.randomUUID()}${ext}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 100 * 1024 * 1024 } });

export const songsRouter = Router();

function rowToSong(row: any): Song {
  return {
    id: row.id,
    title: row.title,
    artist: row.artist,
    bpm: row.bpm,
    songKey: row.song_key,
    difficulty: row.difficulty,
    audioUrl: `/uploads/${path.basename(row.audio_path)}`,
    lrcUrl: row.lrc_path ? `/uploads/${path.basename(row.lrc_path)}` : null,
    coverUrl: row.cover_path ? `/uploads/${path.basename(row.cover_path)}` : null,
  };
}

songsRouter.get('/', (_req, res) => {
  const rows = db.prepare('SELECT * FROM songs ORDER BY created_at DESC').all();
  res.json(rows.map(rowToSong));
});

songsRouter.post(
  '/',
  upload.fields([
    { name: 'audio', maxCount: 1 },
    { name: 'lrc', maxCount: 1 },
    { name: 'cover', maxCount: 1 },
  ]),
  (req, res) => {
    const files = req.files as Record<string, Express.Multer.File[]> | undefined;
    const audioFile = files?.audio?.[0];
    const lrcFile = files?.lrc?.[0];
    const coverFile = files?.cover?.[0];

    if (!audioFile) {
      res.status(400).json({ error: 'Arquivo de áudio é obrigatório.' });
      return;
    }

    const { title, artist, bpm, songKey, difficulty } = req.body as Record<string, string>;
    if (!title || !artist) {
      res.status(400).json({ error: 'Título e artista são obrigatórios.' });
      return;
    }

    const id = crypto.randomUUID();
    db.prepare(
      `INSERT INTO songs (id, title, artist, bpm, song_key, difficulty, audio_path, lrc_path, cover_path, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      title,
      artist,
      bpm ? Number(bpm) : null,
      songKey || null,
      difficulty || null,
      audioFile.path,
      lrcFile?.path ?? null,
      coverFile?.path ?? null,
      Date.now()
    );

    const row = db.prepare('SELECT * FROM songs WHERE id = ?').get(id);
    res.status(201).json(rowToSong(row));
  }
);

songsRouter.delete('/:id', (req, res) => {
  const row: any = db.prepare('SELECT * FROM songs WHERE id = ?').get(req.params.id);
  if (!row) {
    res.status(404).json({ error: 'Música não encontrada.' });
    return;
  }
  for (const p of [row.audio_path, row.lrc_path, row.cover_path]) {
    if (p && fs.existsSync(p)) fs.unlinkSync(p);
  }
  db.prepare('DELETE FROM songs WHERE id = ?').run(req.params.id);
  res.status(204).end();
});

export function getSongRow(songId: string): any {
  return db.prepare('SELECT * FROM songs WHERE id = ?').get(songId);
}
