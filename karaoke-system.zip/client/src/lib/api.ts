import type { Song } from '../types';

// The server is assumed to run on the same host as whoever serves this
// client (the party laptop), on port 3001. Works for localhost, LAN IP, etc.
export const SERVER_HOST = `${window.location.hostname}:3001`;
export const API_BASE = `${window.location.protocol}//${SERVER_HOST}`;
export const WS_URL = `${window.location.protocol === 'https:' ? 'wss' : 'ws'}://${SERVER_HOST}/ws`;

export function assetUrl(path: string): string {
  return `${API_BASE}${path}`;
}

export async function fetchSongs(): Promise<Song[]> {
  const res = await fetch(`${API_BASE}/api/songs`);
  if (!res.ok) throw new Error('Falha ao carregar músicas.');
  return res.json();
}

export async function uploadSong(form: FormData): Promise<Song> {
  const res = await fetch(`${API_BASE}/api/songs`, { method: 'POST', body: form });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? 'Falha ao enviar música.');
  }
  return res.json();
}

export async function deleteSong(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/api/songs/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Falha ao remover música.');
}
