import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import type { Song } from '../types';
import { deleteSong, fetchSongs, uploadSong } from '../lib/api';

export function Admin() {
  const [songs, setSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [bpm, setBpm] = useState('');
  const [songKey, setSongKey] = useState('');
  const [difficulty, setDifficulty] = useState('Médio');
  const audioInputRef = useRef<HTMLInputElement>(null);
  const lrcInputRef = useRef<HTMLInputElement>(null);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [lrcFile, setLrcFile] = useState<File | null>(null);

  async function reload() {
    setLoading(true);
    try {
      setSongs(await fetchSongs());
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    reload();
  }, []);

  async function handleSubmit() {
    setError(null);
    if (!title.trim() || !artist.trim() || !audioFile) {
      setError('Título, artista e arquivo de áudio são obrigatórios.');
      return;
    }
    setSubmitting(true);
    try {
      const form = new FormData();
      form.append('title', title.trim());
      form.append('artist', artist.trim());
      if (bpm) form.append('bpm', bpm);
      if (songKey) form.append('songKey', songKey);
      if (difficulty) form.append('difficulty', difficulty);
      form.append('audio', audioFile);
      if (lrcFile) form.append('lrc', lrcFile);

      await uploadSong(form);
      setTitle('');
      setArtist('');
      setBpm('');
      setSongKey('');
      setAudioFile(null);
      setLrcFile(null);
      if (audioInputRef.current) audioInputRef.current.value = '';
      if (lrcInputRef.current) lrcInputRef.current.value = '';
      await reload();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Falha ao enviar música.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id: string) {
    await deleteSong(id);
    await reload();
  }

  return (
    <div className="min-h-dvh px-6 py-8 max-w-3xl mx-auto flex flex-col gap-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Painel administrativo</h1>
        <Link to="/" className="text-sm text-fuchsia-300 underline">
          Ir para a tela principal
        </Link>
      </div>

      <section className="bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col gap-4">
        <h2 className="font-semibold">Cadastrar música</h2>

        <div className="grid grid-cols-2 gap-3">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Título *"
            className="bg-black/30 border border-white/10 rounded-lg px-3 py-2.5 outline-none focus:border-fuchsia-400/60"
          />
          <input
            value={artist}
            onChange={(e) => setArtist(e.target.value)}
            placeholder="Artista *"
            className="bg-black/30 border border-white/10 rounded-lg px-3 py-2.5 outline-none focus:border-fuchsia-400/60"
          />
          <input
            value={bpm}
            onChange={(e) => setBpm(e.target.value)}
            placeholder="BPM"
            type="number"
            className="bg-black/30 border border-white/10 rounded-lg px-3 py-2.5 outline-none focus:border-fuchsia-400/60"
          />
          <input
            value={songKey}
            onChange={(e) => setSongKey(e.target.value)}
            placeholder="Tom (ex: C, Am)"
            className="bg-black/30 border border-white/10 rounded-lg px-3 py-2.5 outline-none focus:border-fuchsia-400/60"
          />
          <select
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value)}
            className="bg-black/30 border border-white/10 rounded-lg px-3 py-2.5 outline-none focus:border-fuchsia-400/60 col-span-2"
          >
            <option>Fácil</option>
            <option>Médio</option>
            <option>Difícil</option>
          </select>
        </div>

        <label className="flex flex-col gap-1.5">
          <span className="text-xs uppercase tracking-wide text-white/50">
            Áudio (mp3/wav/ogg) *
          </span>
          <input
            ref={audioInputRef}
            type="file"
            accept="audio/*"
            onChange={(e) => setAudioFile(e.target.files?.[0] ?? null)}
            className="text-sm"
          />
        </label>

        <label className="flex flex-col gap-1.5">
          <span className="text-xs uppercase tracking-wide text-white/50">
            Letra sincronizada (.lrc, opcional)
          </span>
          <input
            ref={lrcInputRef}
            type="file"
            accept=".lrc,text/plain"
            onChange={(e) => setLrcFile(e.target.files?.[0] ?? null)}
            className="text-sm"
          />
        </label>

        {error && <p className="text-sm text-red-400">{error}</p>}

        <button
          onClick={handleSubmit}
          disabled={submitting}
          className="rounded-lg py-3 font-semibold bg-gradient-to-r from-fuchsia-500 to-cyan-500 disabled:opacity-40"
        >
          {submitting ? 'Enviando...' : 'Adicionar música'}
        </button>
      </section>

      <section>
        <h2 className="font-semibold mb-3">
          Biblioteca ({loading ? '...' : songs.length})
        </h2>
        <div className="flex flex-col gap-2">
          {songs.map((s) => (
            <div
              key={s.id}
              className="flex items-center justify-between bg-white/5 border border-white/10 rounded-lg px-4 py-3"
            >
              <div>
                <p className="font-medium">{s.title}</p>
                <p className="text-xs text-white/40">
                  {s.artist} {s.bpm ? `· ${s.bpm} BPM` : ''} {s.songKey ? `· Tom ${s.songKey}` : ''}{' '}
                  {s.difficulty ? `· ${s.difficulty}` : ''} {s.lrcUrl ? '· letra ✓' : '· sem letra'}
                </p>
              </div>
              <button
                onClick={() => handleDelete(s.id)}
                className="text-xs text-red-400 hover:text-red-300"
              >
                Remover
              </button>
            </div>
          ))}
          {!loading && songs.length === 0 && (
            <p className="text-white/30 text-sm">Nenhuma música cadastrada ainda.</p>
          )}
        </div>
      </section>
    </div>
  );
}
